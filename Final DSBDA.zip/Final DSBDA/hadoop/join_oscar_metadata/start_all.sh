#!/bin/bash

./pymongo_hadoop_installation.sh
./collection_refactoring_hdfs.sh
./join_oscar_metadata.sh
