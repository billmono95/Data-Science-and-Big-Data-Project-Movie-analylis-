#!/bin/bash
mvn dependency:get -Ddest=./ -Dartifact=org.mongodb.mongo-hadoop:mongo-hadoop-streaming:2.0.2
